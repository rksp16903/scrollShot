# ScrollShot

Aplikasi Android untuk **tangkapan layar panjang (scrolling screenshot)**.
Menggulir layar otomatis, mengambil beberapa screenshot, lalu menyambungkannya menjadi satu gambar PNG.

- Android 11+ (API 30) — memakai `AccessibilityService.takeScreenshot()`
- Tanpa library tambahan, tanpa internet, tanpa izin penyimpanan

## Build di GitHub (tanpa ekstrak)

1. Buat repo baru di GitHub.
2. **Add file → Upload files** → pilih `ScrollShot-source.zip` (biarkan tetap .zip) → Commit.
3. **Add file → Create new file** → nama file: `.github/workflows/build.yml` → tempel isi `build.yml` → Commit.
4. Buka tab **Actions** dan tunggu build selesai (± 3–5 menit).
5. APK ada di tab **Releases** (`ScrollShot.apk`), atau di Actions → run terbaru → Artifacts.

Workflow akan meng-unzip proyek otomatis. Jika repo berisi folder proyek biasa, langkah unzip dilewati.

## Cara pakai di HP

1. Pasang APK. Info Aplikasi → ⋮ → **Izinkan setelan terbatas** (Android 13+).
2. Pengaturan → Aksesibilitas → ScrollShot → aktifkan.
3. Buka halaman yang ingin ditangkap, ketuk tombol biru melayang, jangan sentuh layar sampai selesai.
4. Hasil: Galeri → album **ScrollShot**.

## Batasan

- Maksimal 40 bagian atau tinggi 16.000 px per gambar.
- Aplikasi yang memblokir screenshot (mis. perbankan) akan gagal/hitam.
- Elemen yang menempel (header/footer sticky) bisa tampil berulang.

package com.scrollshot.app

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(20)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(48), pad, pad)
        }

        col.addView(TextView(this).apply {
            text = "ScrollShot"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
        })

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, dp(12), 0, dp(12))
        }
        col.addView(status)

        col.addView(TextView(this).apply {
            textSize = 15f
            text = "Cara pakai:\n\n" +
                "1. Tekan \"Buka Info Aplikasi\" > titik tiga (⋮) > \"Izinkan setelan terbatas\" " +
                "(wajib di Android 13+ untuk aplikasi di luar Play Store).\n\n" +
                "2. Tekan \"Aktifkan Layanan Aksesibilitas\", pilih ScrollShot, lalu aktifkan.\n\n" +
                "3. Buka halaman yang ingin ditangkap (chat, web, dokumen, dll.) " +
                "lalu ketuk tombol biru melayang \"SCROLL SHOT\". Tombol bisa digeser.\n\n" +
                "4. Jangan sentuh layar sampai muncul pemberitahuan \"Selesai\". " +
                "Aplikasi menggulir otomatis sampai ujung halaman.\n\n" +
                "5. Hasil ada di Galeri > album ScrollShot (file PNG)."
        })

        addButton(col, "Buka Info Aplikasi") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
        addButton(col, "Aktifkan Layanan Aksesibilitas") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton(col, "Tampilkan Tombol Melayang") {
            ScrollShotService.instance?.showOverlay()
            refresh()
        }

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        status.text = if (ScrollShotService.instance != null)
            "● Layanan aktif. Tombol melayang tampil di layar."
        else
            "○ Layanan belum aktif."
    }

    private fun addButton(parent: LinearLayout, label: String, onClick: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }
        parent.addView(
            b,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        )
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}

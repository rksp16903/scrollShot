package com.scrollshot.app

import android.graphics.Bitmap
import kotlin.math.abs

/** Peta kecerahan (luminance) yang diperkecil dari sebuah tangkapan layar. */
class Grid(val rows: Int, val cols: Int, val data: ByteArray)

object Stitcher {
    private const val STEP = 6

    fun grid(bmp: Bitmap, top: Int, h: Int): Grid {
        val w = bmp.width
        val cols = (w / STEP).coerceAtLeast(1)
        val line = IntArray(w)
        val data = ByteArray(h * cols)
        for (y in 0 until h) {
            bmp.getPixels(line, 0, w, 0, top + y, w, 1)
            val base = y * cols
            for (c in 0 until cols) {
                val p = line[c * STEP]
                val lum = (((p shr 16) and 0xFF) * 77 +
                    ((p shr 8) and 0xFF) * 150 +
                    (p and 0xFF) * 29) shr 8
                data[base + c] = lum.toByte()
            }
        }
        return Grid(h, cols, data)
    }

    private fun rowDiff(a: Grid, ra: Int, b: Grid, rb: Int): Int {
        var s = 0
        val oa = ra * a.cols
        val ob = rb * b.cols
        for (c in 0 until a.cols) {
            s += abs((a.data[oa + c].toInt() and 0xFF) - (b.data[ob + c].toInt() and 0xFF))
        }
        return s
    }

    private fun variance(g: Grid, y0: Int, n: Int): Double {
        var sum = 0.0
        var sq = 0.0
        var cnt = 0
        var y = y0
        while (y < y0 + n) {
            for (c in 0 until g.cols) {
                val x = (g.data[y * g.cols + c].toInt() and 0xFF).toDouble()
                sum += x
                sq += x * x
                cnt++
            }
            y += 2
        }
        val m = sum / cnt
        return sq / cnt - m * m
    }

    /**
     * Mencari berapa piksel konten bergeser ke atas dari [a] (sebelum gulir) ke [b] (sesudah gulir).
     * Hasil: jumlah piksel baru di bagian bawah [b], atau -1 bila layar tidak bergerak (ujung halaman).
     */
    fun findShift(a: Grid, b: Grid, expected: Int): Int {
        val h = a.rows
        val cols = a.cols

        // 1) Kedua gambar hampir identik -> tidak ada gulir lagi.
        var diff = 0L
        var n = 0
        var yy = 0
        while (yy < h) {
            diff += rowDiff(a, yy, b, yy)
            n += cols
            yy += 3
        }
        if (diff.toDouble() / n < 1.2) return -1

        // 2) Pilih pita (band) di gambar lama yang paling kaya detail.
        val bandH = (h * 0.12).toInt().coerceAtLeast(16)
        var y0 = -1
        var bestVar = -1.0
        for (f in doubleArrayOf(0.75, 0.62, 0.52)) {
            val c = (h * f).toInt()
            if (c + bandH > h) continue
            val v = variance(a, c, bandH)
            if (v > bestVar) {
                bestVar = v
                y0 = c
            }
        }
        if (y0 < 0) return expected

        // 3) Cari pergeseran d yang membuat pita cocok dengan gambar baru.
        val maxD = y0
        val scores = DoubleArray(maxD + 1)
        val rowsUsed = (bandH + 1) / 2
        var min = Double.MAX_VALUE
        for (d in 0..maxD) {
            var s = 0L
            var r = 0
            while (r < bandH) {
                s += rowDiff(a, y0 + r, b, y0 - d + r)
                r += 2
            }
            val sc = s.toDouble() / (rowsUsed * cols)
            scores[d] = sc
            if (sc < min) min = sc
        }

        if (bestVar < 25.0) return expected      // pita polos -> tidak bisa dicocokkan, pakai perkiraan
        if (min > 18.0) return expected          // tidak ada kecocokan yang baik
        if (scores[0] <= min + 0.3) return -1    // kecocokan terbaik = tidak bergerak

        var best = -1
        var bestDist = Int.MAX_VALUE
        for (d in 1..maxD) {
            if (scores[d] <= min + 0.5) {
                val dist = abs(d - expected)
                if (dist < bestDist) {
                    bestDist = dist
                    best = d
                }
            }
        }
        return if (best < 4) -1 else best
    }
}

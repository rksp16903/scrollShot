package com.scrollshot.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.min

class ScrollShotService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ScrollShotService? = null

        private const val MAX_FRAMES = 40
        private const val MAX_HEIGHT = 16000
        private const val MIN_SHOT_INTERVAL_MS = 1150L
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var overlay: TextView? = null

    @Volatile
    private var busy = false

    @Volatile
    private var lastShot = 0L

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        showOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        removeOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        worker.shutdownNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ overlay

    fun showOverlay() {
        main.post {
            val existing = overlay
            if (existing != null) {
                existing.visibility = View.VISIBLE
                return@post
            }
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val density = resources.displayMetrics.density
            val size = (64 * density).toInt()

            val tv = TextView(this).apply {
                text = "SCROLL\nSHOT"
                textSize = 9f
                setTextColor(Color.WHITE)
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                setBackgroundResource(R.drawable.overlay_bg)
            }
            val lp = WindowManager.LayoutParams(
                size, size,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 0
                y = resources.displayMetrics.heightPixels / 3
            }

            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var moved = false
            tv.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = ev.rawX
                        downY = ev.rawY
                        startX = lp.x
                        startY = lp.y
                        moved = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (ev.rawX - downX).toInt()
                        val dy = (ev.rawY - downY).toInt()
                        if (abs(dx) > 12 || abs(dy) > 12) moved = true
                        if (moved) {
                            lp.x = startX + dx
                            lp.y = startY + dy
                            wm.updateViewLayout(v, lp)
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) startCapture()
                        true
                    }
                    else -> false
                }
            }
            try {
                wm.addView(tv, lp)
                overlay = tv
            } catch (e: Exception) {
                toast("Gagal menampilkan tombol: ${e.message}")
            }
        }
    }

    private fun removeOverlay() {
        main.post {
            overlay?.let {
                try {
                    (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)
                } catch (_: Exception) {
                }
            }
            overlay = null
        }
    }

    private fun setOverlayVisible(visible: Boolean) {
        main.post { overlay?.visibility = if (visible) View.VISIBLE else View.INVISIBLE }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    // ------------------------------------------------------------------ capture

    private fun startCapture() {
        if (busy) return
        busy = true
        setOverlayVisible(false)
        worker.execute {
            try {
                runCapture()
            } catch (t: Throwable) {
                toast("Gagal: ${t.message}")
            } finally {
                busy = false
                setOverlayVisible(true)
            }
        }
    }

    private fun runCapture() {
        Thread.sleep(500) // beri waktu tombol melayang menghilang

        val first = grab()
        if (first == null) {
            toast("Gagal mengambil layar. Coba lagi.")
            return
        }

        val w = first.width
        val top = min(barHeight("status_bar_height"), first.height / 8)
        val bottom = min(navHeight(), first.height / 8)
        val h = first.height - top - bottom
        val expected = (h * 0.45f).toInt()

        val parts = ArrayList<Bitmap>()
        parts.add(cropCopy(first, 0, top, w, h))
        var total = h
        var prev: Bitmap = first
        var prevGrid = Stitcher.grid(prev, top, h)
        var frames = 1

        while (frames < MAX_FRAMES && total < MAX_HEIGHT) {
            if (!swipe(w, top, h)) break
            Thread.sleep(800) // tunggu animasi/inertia berhenti
            val next = grab() ?: break
            val g = Stitcher.grid(next, top, h)
            val d = Stitcher.findShift(prevGrid, g, expected)
            if (d <= 0) {
                next.recycle()
                break
            }
            parts.add(cropCopy(next, 0, top + h - d, w, d))
            total += d
            frames++
            prev.recycle()
            prev = next
            prevGrid = g
        }
        prev.recycle()

        val out = Bitmap.createBitmap(w, total, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        var y = 0f
        for (p in parts) {
            canvas.drawBitmap(p, 0f, y, null)
            y += p.height
            p.recycle()
        }

        val saved = save(out)
        out.recycle()
        if (saved) {
            toast(
                if (frames == 1) "Halaman tidak bisa digulir. 1 tangkapan disimpan di Galeri > ScrollShot"
                else "Selesai ($frames bagian). Tersimpan di Galeri > ScrollShot"
            )
        } else {
            toast("Gagal menyimpan gambar")
        }
    }

    /** Ambil satu tangkapan layar (blocking). */
    private fun grab(): Bitmap? {
        for (attempt in 0 until 6) {
            val wait = MIN_SHOT_INTERVAL_MS - (System.currentTimeMillis() - lastShot)
            if (wait > 0) Thread.sleep(wait)

            val latch = CountDownLatch(1)
            var result: Bitmap? = null
            var failCode = 0

            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                        try {
                            val hb = screenshot.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                            result = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            hw?.recycle()
                            hb.close()
                        } catch (_: Throwable) {
                        }
                        latch.countDown()
                    }

                    override fun onFailure(errorCode: Int) {
                        failCode = errorCode
                        latch.countDown()
                    }
                }
            )
            latch.await(5, TimeUnit.SECONDS)
            lastShot = System.currentTimeMillis()

            val bmp = result
            if (bmp != null) return bmp
            if (failCode == 0 && attempt >= 2) return null
        }
        return null
    }

    /** Geser jari dari bawah ke atas (konten bergulir turun). */
    private fun swipe(w: Int, top: Int, h: Int): Boolean {
        val x = w / 2f
        val y1 = top + h * 0.78f
        val y2 = top + h * 0.33f
        val path = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 450))
            .build()

        val latch = CountDownLatch(1)
        var ok = false
        val accepted = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    ok = true
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            },
            null
        )
        if (!accepted) return false
        latch.await(4, TimeUnit.SECONDS)
        return ok
    }

    // ------------------------------------------------------------------ helpers

    private fun cropCopy(src: Bitmap, x: Int, y: Int, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(src, x, y, w, h)
        return if (b === src) src.copy(Bitmap.Config.ARGB_8888, false) else b
    }

    private fun barHeight(name: String): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun navHeight(): Int {
        val mode = try {
            Settings.Secure.getInt(contentResolver, "navigation_mode")
        } catch (_: Exception) {
            0
        }
        return if (mode == 2) (24 * resources.displayMetrics.density).toInt()
        else barHeight("navigation_bar_height")
    }

    private fun save(bmp: Bitmap): Boolean {
        return try {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "ScrollShot_$stamp.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ScrollShot")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return false
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            true
        } catch (_: Throwable) {
            false
        }
    }
}
